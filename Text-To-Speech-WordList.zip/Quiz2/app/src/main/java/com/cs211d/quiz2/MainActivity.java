package com.cs211d.quiz2;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;

import android.view.View;
import android.view.Window;

import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import android.widget.TextView;

import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity
{
    //SQLiteDatabase item
    private SQLiteDatabase myDB = null;
    private final String DB_NAME = "mydb.db";
    private final String TABLE_NAME = "dictionarytable";

    //instantiate the items in view
    public TextView countDefinitions;
    public EditText searchText;
    public ListView listView;

    //list to hold words
    public ArrayList<String> al = new ArrayList<>();
    public ArrayList<String> currentAl = new ArrayList<>();
    public ArrayList<String> pronounceAl = new ArrayList<>();

    //Text to Speech
    public TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Connect items in view to controller
        countDefinitions = (TextView) findViewById(R.id.countView);
        searchText = (EditText) findViewById(R.id.searchTxt);
        listView = (ListView)  findViewById(R.id.list_view);

        //set ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this,
                android.R.layout.simple_list_item_multiple_choice, android.R.id.text1, currentAl);
        listView.setAdapter(adapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);


        //check if Datebase exist; if so open database; if not create database.
        if (!existsDatabase())
        {
            createDatabase();
        }
        else
        {
            myDB = openOrCreateDatabase(DB_NAME, MODE_PRIVATE, null);
        }
    }
    //*********************Function For Count, Pronounce and Search Buttons***********************

    //*******************************count()***********************************************

    //print to current arraylist count to screen
    public void count(View view)
    {
        countDefinitions.setText("Count: " + currentAl.size());
    }

    //*******************************pronounce()*******************************************

    //pronounce the selected words
    public void pronounce(View view)
    {
        //Declare that we are pronouncing
        countDefinitions.setText("PRONOUNCING");

        //clear pronounceAl
        pronounceAl.clear();

        //make sure there are words to be selected
        if (currentAl.size() != 0)
        {
            //get the key-value pair for items and truth value as being selected or not
            SparseBooleanArray sba = listView.getCheckedItemPositions();
            for (int i = 0; i < sba.size(); i++)
            {
                //if selected add to pronounceAl otherwise remove
                if (sba.valueAt(i))
                {
                    {
                        pronounceAl.add(currentAl.get(sba.keyAt(i)));
                    }
                }
                else
                {
                    pronounceAl.remove(currentAl.get(sba.keyAt(i)));
                }

            }

            //Use TextToSpeech to pronounce each item in pronounceAL list
            tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener()
            {
                @Override
                public void onInit(int status)
                {
                    if (status != TextToSpeech.ERROR)
                    {
                        tts.setLanguage(Locale.UK);
                    }
                    for (int i = 0; i < pronounceAl.size(); i++)
                    {
                        tts.speak(pronounceAl.get(i), TextToSpeech.QUEUE_ADD, null, null);
                    }
                }
            });

            //Tell User that Pronounce function has been completed
            countDefinitions.setText("PRONOUNCED");
        }
    }
    //*******************************search()*********************************************

    //search for word/regex
    public void search(View view)
    {
        //print to screen count
        countDefinitions.setText("SEARCHING");

        //clear currentAl
        currentAl.clear();

        //Get input
        String input = searchText.getText().toString().trim();

        //if input empty immediately return
        if (input.equals(""))
        {
            return;
        }

        //query word in sqlite database
        Cursor c;
        c = myDB.rawQuery("SELECT word FROM dictionarytable " +
                        "WHERE word REGEXP ?",
                new String[]{input});

        //if we get words put them into currentAl
        if (c.getCount() > 0)
        {
//            c.moveToFirst();]
            while (!c.isLast())
            {     c.moveToNext();
                  String word = c.getString(0);
                  currentAl.add(word);
            }

        }

        //tell user we have completed search
        countDefinitions.setText("SEARCHED");
        return;
    }

    //*****************************Helper Functions Database **************************************

    //*******************************parseDictionary()*************************************
    //read dictionary from assets file and put into arraylist to be processed into sqlite
    private void parseDictionary(ArrayList<String> al)
    //learned to read text file from assests folder using the following link
    // https://stackoverflow.com/questions/10982252/android-reading-a-file-using-scanner-
    // how-to-get-to-the-file?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
    {
        try {
            DataInputStream textFileStream = new DataInputStream(getAssets().open(String.format("dictionary.txt")));
            Scanner sc = new Scanner(textFileStream);
            while (sc.hasNextLine()) {
                String aLine = sc.nextLine();
                al.add(aLine);
                System.out.println(aLine);
            }
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //*******************************createDatabalse()*************************************
    //Convert arraylist to SQlite dictionary
    private void createDatabase()
    {

        //Get Dictionary into array
        parseDictionary(al);
        myDB = openOrCreateDatabase(DB_NAME, MODE_PRIVATE, null);
        myDB.setVersion(1);
        myDB.execSQL("create table if not exists dictionarytable(word text)");

        //To insert data to the table:
        ContentValues cv = new ContentValues();
        int i;
        for (i = 0; i < al.size(); i++)
        {
            Log.d("dictionaryInput", al.get(i));
            cv.put("word", al.get(i));
            long record_id = myDB.insert(TABLE_NAME, null, cv);
        }
    }

    //*******************************existsDatabase()*************************************
    //Check if Database already exist
    private boolean existsDatabase()
    {
        File dbFile = getDatabasePath(DB_NAME);
        return dbFile.exists();
    }

    //*************************remove_activity_title()************************************
    //Removes title from activity
    public void remove_activity_title(Activity activity)
    {
        activity.requestWindowFeature(Window.FEATURE_NO_TITLE);
    }

}
